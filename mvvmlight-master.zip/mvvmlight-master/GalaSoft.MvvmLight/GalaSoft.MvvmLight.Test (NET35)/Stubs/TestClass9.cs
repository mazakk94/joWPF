﻿namespace GalaSoft.MvvmLight.Test.Stubs
{
    public class TestClass9
    {
        public TestClass9()
        {
            
        }

        internal TestClass9(string param)
        {
            
        }
    }
}
