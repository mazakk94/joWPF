namespace GalaSoft.MvvmLight.Test.Stubs
{
    public class TestClass8
    {
        static TestClass8()
        {
            
        }

        public TestClass8()
        {
            
        }
    }
}