﻿using System.Runtime.InteropServices;

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("af3b47b5-6e14-4512-89a6-5c3e6cac5e35")]
