﻿using System.Runtime.InteropServices;

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("F722ADF7-2AF5-48C5-8C3F-B13E575ED1AD")]
